package com.langfeiyes.rest.controller;

import com.langfeiyes.rest.domain.user;
import com.langfeiyes.rest.util.JsonResult;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@RestController  // @Controller  + @ResponseBody
@RequestMapping()
public class userController {
    List<user> list=new ArrayList<user>();
//    list.add(new user("TaroYamada","たろー","123456","僕は元気です"));
    @RequestMapping(path="/users/{user_id}", method=RequestMethod.GET)
    @ResponseBody
    public JsonResult list(@PathVariable String user_id){
        user user1=null;
        boolean flag=false;
        for (int index = list.size()-1;index>=0;index--){
            user user = list.get(index);
            if (user.getUser_id().equals(user_id)){
                user1 = user;
                flag=true;
                break;
            }
        }
        if (flag){
            return new JsonResult(200,"get Successfully",user1);
        }
        else{
            return new JsonResult(500,"account not found",null);
        }
    }
////    @GetMapping("/{id}")
////    public user detail(@PathVariable Long id){
////        return new user(id, "dafei", 18);
////    }
//
//
//    @RequestMapping(path="/signup", method=RequestMethod.POST,params = {"user_id","password"})
    @RequestMapping(path="/signup", method=RequestMethod.POST)
    @ResponseBody

    public JsonResult signup(@RequestParam("user_id") String user_id,
                             @RequestParam("password") String password,
                             @RequestParam(value = "comment", required = false) String comment,
                             @RequestParam(value = "nickname", required = false) String nickname){
        if (user_id==null || password==null){
            return new JsonResult(400,"Account creation failed",null,"required user_id and password");
        }
        if (user_id.length()<6 || user_id.length()>20){
            return new JsonResult(400,"Account creation failed",null,"user_id's length should be 6-20");
        }
        if (password.length()<8 || password.length()>20){
            return new JsonResult(400,"Account creation failed",null,"password's length should be 6-20");
        }
        if (!user_id.matches("[0-9]+")){
            return new JsonResult(400,"Account creation failed",null,"user_id's pattern should be half number");
        }
        if (!user_id.matches("[0-9]+")){
            return new JsonResult(400,"Account creation failed",null,"password's length should be 6-20");
        }
        user user = new user(user_id,nickname,password,comment);
        list.add(user);
        user user1 = new user(user_id,nickname,null,null);
        return new JsonResult(200,"Account successfully created",user1);
//        return new user(user_id,nickname,password,comment);
    }
    @PatchMapping("/users/{user_id}")
    public JsonResult update(@PathVariable String user_id){
//        user.setName(user.getName() + "_update");
        user user1=null;
        boolean flag=false;
        for (int index = list.size()-1;index>=0;index--){
            user user = list.get(index);
            if (user.getUser_id().equals(user_id)){
                user.setNickname(user.getNickname() + "_update");
                user1 = user;
                flag=true;
                break;
            }
        }
        if (flag){
            return new JsonResult(200,"update Successfully",user1);
        }
        else{
            return new JsonResult(500,"account not found",null);
        }
    }
    @PostMapping("/close")
    public JsonResult delete(@RequestParam("user_id") String user_id){
        boolean flag = false;
        user user1=null;
        for (int index = list.size()-1;index>=0;index--){
            user user = list.get(index);
            if (user.getUser_id().equals(user_id)){
                user1 = list.remove(index);
                flag=true;
                break;
            }
        }
        if (flag){
            return new JsonResult(200,"Success",user1);
        }
        else{
            return new JsonResult(500,"account not found",null);
        }
    }
    @GetMapping("/test")
    public user hello(){
        return new user("123", "dafei", "18","1212");
    }
}
