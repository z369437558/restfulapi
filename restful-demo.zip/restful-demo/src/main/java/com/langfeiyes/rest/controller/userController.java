package com.langfeiyes.rest.controller;

import com.langfeiyes.rest.domain.user;
import com.langfeiyes.rest.util.JsonResult;
import org.springframework.web.bind.annotation.*;


@RestController  // @Controller  + @ResponseBody
@RequestMapping()
public class userController {
    @RequestMapping(path="/users/{user_id}", method=RequestMethod.GET)
    @ResponseBody
    public user list(){
        return new user("TaroYamada","たろー","123456","僕は元気です");
    }
//    @GetMapping("/{id}")
//    public user detail(@PathVariable Long id){
//        return new user(id, "dafei", 18);
//    }


    @RequestMapping(path="/signup", method=RequestMethod.POST,params = {"user_id","password"})
    @ResponseBody
    public JsonResult signup(@RequestParam("user_id") String user_id,
                             @RequestParam("password") String password,
                             @RequestParam(value = "comment", required = false) String comment,
                             @RequestParam(value = "nickname", required = false) String nickname){
        user user  = new user(user_id,nickname,password,comment);
//        if user.getUser_id().length()<6 || user.getUser_id().length()>20{
//        }
        return JsonResult.success(user);
    }
    @PatchMapping("/users/{user_id}")
    public JsonResult update(user user){
//        user.setName(user.getName() + "_update");
        return JsonResult.success(user);
    }
    @PostMapping("/close")
    public JsonResult delete(){
        return JsonResult.success();
    }
}
